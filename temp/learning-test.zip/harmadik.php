<?php
if (!empty($_GET['q'])) {
  switch ($_GET['q']) {
    case 'info':
      phpinfo();
      exit;
      break;
  }
}

$num = 8 * 2;
echo floor($num / 10) + ($num % 10);


function test($str)
{
  $str = trim($str);
  $str = strip_tags($str);
  $str = stripslashes($str);
  return $str;
}

// error texts
$nameErr = "";
$usernameErr = "";
$passwordErr = "";
$nameErr = "";
$emailErr = "";

$comment = "";
$sex = "";

$pets = null;
$countries = null;

if ($_SERVER['REQUEST_METHOD'] === "POST") {

  if (
    isset($_POST['name']) &&
    !empty($_POST['name']) &&
    $_POST['name'] === test($_POST['name']) &&
    preg_match("/^[a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ\s]*$/u", $_POST['name']) &&
    strlen($_POST['name']) <= 40
  ) {
    $name = $_POST['name'];
  } else {
    $nameErr = "Hibás név!";
  }


  if (
    isset($_POST['username']) &&
    !empty($_POST['username']) &&
    $_POST['username'] === test($_POST['username']) &&
    preg_match("/^[a-zA-Z]*$/", $_POST['username']) &&
    strlen($_POST['username']) <= 40 &&
    strlen($_POST['username']) >= 8

  ) {
    $username = $_POST['username'];
  } else {
    $usernameErr = "Hibás felhasználónév!";
  }


  if (
    isset($_POST['password']) &&
    !empty($_POST['password']) &&
    strlen($_POST['password']) <= 40 &&
    strlen($_POST['password']) >= 10
  ) {
    $password = $_POST['password'];
  } else {
    $passwordErr = "Hibás jelszó!";
  }


  if (
    isset($_POST['email']) &&
    !empty($_POST['email']) &&
    filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)
  ) {
    $email = $_POST['email'];
  } else {
    $emailErr = "Hibás jelszó!";
  }

  if (isset($_POST['comment'])) {
    $comment = $_POST['comment'];
  } else {
  }

  if (isset($_POST['sex'])) {
    $sex = $_POST['sex'];
  }

  if (isset($_POST['pets'])) {
    $pets = $_POST['pets'];
  }

  if (isset($_POST['countries'])) {
    $countries = $_POST['countries'];
  }
}

?>
<!DOCTYPE html>
<html>

<head>
  <title>Laragon</title>

  <link href="https://fonts.googleapis.com/css?family=Karla:400" rel="stylesheet" type="text/css">

  <style>
    html,
    body {
      height: 100%;
    }

    body {
      margin: 0;
      padding: 0;
      width: 100%;
      display: table;
      font-weight: 100;
      font-family: 'Karla';
    }

    .container {
      padding: 1rem 2rem;
      /* text-align: center; */
      text-align: left;
    }

    .content {}

    .title {
      font-size: 96px;
    }

    .opt {
      margin-top: 30px;
    }

    .opt a {
      text-decoration: none;
      font-size: 150%;
    }

    a:hover {
      color: red;
    }

    .table {
      margin-top: 1.5rem;
      margin-bottom: 1.5rem;
      font-size: 20px;
      border-collapse: collapse;
      border-spacing: 0;
      width: 100%;
    }

    .table tr:nth-child(odd) {
      padding: 10px;
      background-color: #eee;
    }

    .table td {
      padding: 10px;
      color: red;
    }

    tr.tr>th {
      background: gray;
      color: white;
      padding: 10px;
    }
  </style>

  <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script type="text/javascript" src="ajax.js"></script>
</head>

<body>
  <div class="container">
    <div class="content">
      <div class="info"><br />
        <?php print($_SERVER['SERVER_SOFTWARE']); ?><br />
        PHP version: <?php print phpversion(); ?> <span><a title="phpinfo()" href="/?q=info">info</a></span><br />
        Document Root: <?php print($_SERVER['DOCUMENT_ROOT']); ?><br />

      </div>
      <h1><?php echo $_SERVER['SCRIPT_NAME']; ?></h1>

      <!-- <form action="gyakorlas/teszt.php" method="get">
        <div style="margin-bottom: 15px;">
          <label for="vezeteknev">Vezetéknév:</label><br />
          <input type="text" name="vezeteknev" />
        </div>
        <div  style="margin-bottom: 15px;">
          <label for="vezeteknev">Keresztnév:</label><br />
          <input type="text" name="keresztnev" />
        </div>
        <input type="submit" value="Küldés">
      </form> -->

      <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
        <div style="margin-bottom: 15px;">
          <label for="name">Név: *</label><br /><?php echo $nameErr . "<br />"; ?>
          <input type="text" name="name" />
        </div>
        <div style="margin-bottom: 15px;">
          <label for="username">Felhasználónév: *</label><br /><?php echo $usernameErr . "<br />"; ?>
          <input type="text" name="username" />
        </div>

        <div style="margin-bottom: 15px;">
          <label for="password">Jelszó: *</label><br /><?php echo $passwordErr . "<br />"; ?>
          <input type="password" name="password" />
        </div>

        <div style="margin-bottom: 15px;">
          <label for="email">E-mail cím: *</label><br /><?php echo $emailErr . "<br />"; ?>
          <input type="text" name="email" />
        </div>

        <div style="margin-bottom: 15px;">
          <label for="comment">Magamról:</label><br />
          <textarea name="comment" id="" cols="30" rows="6"></textarea>
        </div>

        <div style="margin-bottom: 15px;">
          <label for="sex">Nem:</label><br />
          <input type="radio" name="sex" value="Férfi" /> Férfi
          <input type="radio" name="sex" value="Nő" /> Nő
        </div>

        <div style="margin-bottom: 15px;">
          <label for="pets[]">Háziállatok:</label><br />
          <input type="checkbox" name="pets[]" value="Kutya" /> Kutya
          <input type="checkbox" name="pets[]" value="Macska" /> Macska
          <input type="checkbox" name="pets[]" value="Hal" /> Hal
        </div>
        <div style="margin-bottom: 15px;">
          <label for="countries[]">Kedvenc országaim:</label><br />
          <select multiple="true" name="countries[]" id="">
            <option value="Japán">Japán</option>
            <option value="Magyarország">Magyarország</option>
            <option value="USA">USA</option>
            <option value="Németország">Németország</option>
          </select>
        </div>

        <input type="submit" value="Send">
      </form>

      <?php

      if (isset($name) && isset($username) && isset($password) && isset($email)) {

        echo $name . '<br />' . $username . '<br />' . $password . '<br />' . $email . '<br />' . $sex . '<br />';

        echo '<br />';
        foreach ($pets as $pet) {
          echo $pet . '<br />';
        }

        echo '<br />';
        foreach ($countries as $country) {
          echo $country . '<br />';
        }
      }


      /*
      // // If username isset and not empty
      // if (isset($_POST['username']) && !empty($_POST['username'])) {
      //   $username = $_POST['username'];
      // }
      // // Jelszó
      // if (isset($_POST['password']) && !empty($_POST['password'])) {
      //   $password = $_POST['password'];
      // }

      // // E-mail
      // if (isset($_POST['email']) && !empty($_POST['email'])) {
      //   $email = $_POST['email'];
      // }

      // // Irányítószám
      // if (isset($_POST['zipcode']) && !empty($_POST['zipcode'])) {
      //   $zipcode = $_POST['zipcode'];
      // }


      if (isset($username) && isset($password) && isset($zipcode) && isset($email)) {
        // echo $username . ' ' . $password;
        echo "<br />";

        if (preg_match("/^.+@.+\.[a-z]{2,}$/", $email)) {
          echo $email;
          echo "<br />";
        } else {
          echo 'Email címet adj meg! Lehet, hogy elírtál valamit.';
          echo "<br />";
        }

        if (preg_match("/^(\d){4}$/", $zipcode)) {
          echo $zipcode;
          echo "<br />";
        } else {
          echo 'Az irányítószám csak 4 szám lehet';
          echo "<br />";
        }
      }
*/

      // $str = '<script type="text/javascript">alert("hahahahahha");</script>';
      // $str = 'helló! ';
      // $str = '&#112;';
      // echo $str;
      // echo "<br />";
      // echo htmlspecialchars($str);
      // echo htmlentities($str);
      // echo strip_tags($str);
      // echo stripslashes($str);
      // echo (trim($str));



      ?>
    </div>

  </div>
</body>

</html>