<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>
  <?php
  if (isset($_COOKIE['name']) && !empty($_COOKIE['name'])) {
    echo '<p>Szia ' . $_COOKIE['name'] . '! <a href="delete-cookie.php" >Süti törlése</a></p>';
  } else {
  ?>
    <form action="set-cookie.php" method="post">
      <label for="name">Név</label><br />
      <input type="text" name="name" />
      <input type="submit" value="Submit" />
    </form>

  <?php
  }
  ?>


  <?php
  ?>


</body>

</html>