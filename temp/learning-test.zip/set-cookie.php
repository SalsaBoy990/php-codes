<?php
if(isset($_POST['name']) && !empty($_POST['name'])) {
  // 3600 = 1 óra
  setcookie('name', $_POST['name'], time()+3600);
}
header('Location: negyedik.php');
?>