$(document).ready(function () {
  $('#btn').click(function() {
    $('#con').load('adat.html');
  })
});