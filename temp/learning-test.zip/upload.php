<?php

  // if( isset($_POST['submit'])) {
  //   echo '<pre>';
  //   print_r($_FILES['file']);
  //   echo '</pre>';
    
  //   move_uploaded_file($_FILES['file']['tmp_name'], 'images/' . $_FILES['file']['name']);
    
  // }
  
  if ( isset($_POST['submit'])) {
    // méret
    // if () {
    //   //formátum
    //   if () {
    //     // létezik-e
    //     if () {

    //     }
    //   }
    // }

    //---------------------------------
    $errors = array();
    $van = true;
    $type = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    echo $type;

    // random
    $_FILES['image']['name'] = date('Ymdhis').mt_rand() . '.' . $type;
    if ( !($type === 'jpeg' || $type === 'jpg' || $type === 'png' || $type === 'gif') ) {
      $van = false;
      array_push($errors, 'Csak jpg, png és gif formátumok feltöltése engedélyezett.');
    }
    // max 500 KB
    if ($_FILES['image']['size'] > 500000 ) {
      $van = false;
      array_push($errors, 'A fájl mérete nem lehet nagyobb, mint 500 KB.');
    }
    if (file_exists("images/" . $_FILES['image']['name'])) {
      $van = false;
      array_push($errors, 'Ilyen nevű fájl már létezik.');
    }
    if ($van) {
      move_uploaded_file($_FILES['image']['tmp_name'], "images/" . $_FILES['image']['name']);
    echo '<img src="images/'. $_FILES['image']['name']. '" />';
    } else {
      echo '<pre>';
      print_r($errors);
      echo '</pre>';
    }

  }
