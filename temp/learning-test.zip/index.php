<!DOCTYPE html>
<html>

<head>
  <title>Laragon</title>

  <link href="https://fonts.googleapis.com/css?family=Roboto:400" rel="stylesheet" type="text/css">

  <style>
    html,
    body {
      height: 100%;
    }

    body {
      margin: 0;
      padding: 0;
      width: 100%;
      display: table;
      font-weight: 100;
      font-family: 'Roboto';
    }

    .container {
      padding: 1rem 2rem;
      /* text-align: center; */
      text-align: left;
    }

    .content {}

    .title {
      font-size: 96px;
    }

    .opt {
      margin-top: 30px;
    }

    .opt a {
      text-decoration: none;
      font-size: 150%;
    }

    a:hover {
      color: red;
    }

    .table {
      margin-top: 1.5rem;
      margin-bottom: 1.5rem;
      font-size: 20px;
      border-collapse: collapse;
      border-spacing: 0;
      width: 100%;
    }

    .table tr:nth-child(odd) {
      padding: 10px;
      background-color: #eee;
    }

    .table td {
      padding: 10px;
      color: red;
    }

    tr.tr>th {
      background: gray;
      color: white;
      padding: 10px;
    }
  </style>

  <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script type="text/javascript" src="ajax.js"></script>
</head>

<body>
  <div class="container">
    <div class="content">
      <div class="info"><br />
        <?php print($_SERVER['SERVER_SOFTWARE']); ?><br />
        PHP version: <?php print phpversion(); ?> <span><a title="phpinfo()" href="/?q=info">info</a></span><br />
        Document Root: <?php print($_SERVER['DOCUMENT_ROOT']); ?><br />

      </div>
      <h1><?php echo $_SERVER['SCRIPT_NAME']; ?></h1>

      <?php




      // // echo readfile('text.txt');
      // $file = fopen('data.txt', 'r') or die('A fájlt nem tudtuk megnyitni!');
      // // echo utf8_encode(fread($file, filesize('data.txt')));

      // while(!feof($file)) {
      //   // echo mb_convert_encoding(fgets($file), 'UTF8', 'ISO-8859-2') . '<br />';
      //   echo mb_convert_encoding(fgetc($file), 'UTF8', 'ISO-8859-2') . '<br />';
      // }
      // fclose($file);

      // $file = fopen('data.txt', 'w') or die('Nem nyitható meg');

      // fwrite($file, iconv('utf-8', 'ISO-8859-2', "kdrhdjhd\r\n"));
      // fwrite($file, iconv('utf-8', 'ISO-8859-2', "űőéáÁŰÉŰÉÉŰÚŰÓ\r\n"));
      // fwrite($file, iconv('utf-8', 'ISO-8859-2', "űőéáÁŰÉŰÉÉŰÚŰÓ\r\n"));
      // fclose($file);

      // $file = fopen('data.txt', 'a') or die('Gond van a fájllal!');

      // fwrite($file, iconv('utf-8', 'ISO-8859-2', "kdrhdjhd\r\n"));
      // fwrite($file, iconv('utf-8', 'ISO-8859-2', "űőéáÁŰÉŰÉÉŰÚŰÓ\r\n"));
      // fwrite($file, iconv('utf-8', 'ISO-8859-2', "űőéáÁŰÉŰÉÉŰÚŰÓ\r\n"));

      // fclose($file);



      // Szeretem az almát, mert finom.
      // Nagyon szép időnk van.
      // Árvíztűrő tükörfúrógép
      // ÉÁŐÜÖ
      ?>


      <form action="upload.php" method="post" enctype="multipart/form-data">
        <input type="file" name="image" value="Fájl kiválasztása..." />
        <input type="submit" name="submit" value="Feltöltés" />

      </form>


    </div>
  </div>
</body>

</html>