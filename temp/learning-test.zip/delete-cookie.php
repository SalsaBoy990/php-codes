<?php
  // delete cookie
  setcookie('name', '', time()-3600);
  header('Location: negyedik.php');
?>