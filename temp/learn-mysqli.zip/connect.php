<?php
// error_reporting(0);
  $db = new mysqli('127.0.0.1', 'root', '', 'weboldal');

  if ($db->connect_errno) {
    echo $db->connect_error . '<br />';
    die('Adatbázis kapcsolat hiba.');
  } else {
    // echo '<pre>';
    // print_r($db);
    // echo '</pre>';
  }
