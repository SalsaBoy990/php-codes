<?php

require_once 'connect.php';

if (isset($_GET['keresztnev']) && !empty($_GET['keresztnev'])) {
  $kernev = $_GET['keresztnev'];
  echo $kernev;
  if ($db->query(
    "
    INSERT INTO `emberek` (`id`, `vezeteknev`, `keresztnev`, `adatok`, `csatlakozas`) 
    VALUES (NULL, 'Fekete', '"  . $kernev . "', 'Valami cucc', NOW() )
    "
  )) {
    echo $db->affected_rows;
  }
}


$db->close();
