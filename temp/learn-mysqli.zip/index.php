<?php
require_once 'connect.php';


// CRUD!!

// READ, get
// if ($result = $db->query("SELECT * FROM `emberek` WHERE `id`=2")) {
// if ($result = $db->query("SELECT * FROM `emberek`")) {
	// echo '<pre>';
	// print_r($result);
	// echo '</pre>';

	// Táblába
	// $table = $result->fetch_all();
	// // Print records
	// foreach ($table as $row) {
	// 	foreach ($row as $record) {
	// 		echo $record . '*';
	// 	}
	// 	echo '<br />';
	// }

	// echo $table[0][1];


	// $table = $result->fetch_all(MYSQLI_ASSOC);
	// // Print records
	// echo '<pre>';
	// print_r($table);
	// echo '</pre>';
	// foreach ($table as $row) {
	// 	foreach ($row as $record) {
	// 		echo $record . '*';
	// 	}
	// 	echo '<br />';
	// }
	// echo $table[0]['vezeteknev'];


	// Sorok
	// echo '<pre>';
	// print_r($result);
	// echo '</pre>';
	// if ($result->num_rows) {
	// 	// MYSQLI_ASSOC
	// 	// $row = $result->fetch_array(MYSQLI_NUM);
	// 	$row = $result->fetch_assoc();
	// 	foreach ($row as $key=>$record) {
	// 		echo '<b>' . $key . '</b>=>' . $record . '<br/>';
	// 	}
	// 	echo $row['keresztnev'];
	// } else {
	// }

	// if ($result->num_rows) {
	// 	while ($row = $result->fetch_assoc()) {
	// 		echo $row['vezeteknev'] . ' ' . $row['keresztnev'] . '<br />';
	// 	}
	// } else {
	// }


	// Objektum
// 	if ($result->num_rows) {
// 		// $row = $result->fetch_object();
// 		// echo '<pre>';
// 		// print_r($row);
// 		// echo '</pre>';

// 		// echo $row->vezeteknev;

// 		$table = array();

// 		while ($row = $result->fetch_object()) {
// 			array_push($table, $row);
// 		}
// 		echo '<pre>';
// 		print_r($table);
// 		echo '</pre>';
// 	} else {
// 	}
// } else {
// }


// UPDATE, put
// if($db->query("UPDATE `emberek` SET `csatlakozas`=NOW() WHERE `id`=1")) {
// 	echo $db->affected_rows . ' sor módosult.';

// } else {

// }


// post, create


// DELETE
if($delete = $db->query("DELETE FROM `emberek` WHERE `id`=3")) {
	echo $db->affected_rows . ' sor törölve.';

} else {

}


// $result->free();
$db->close();
