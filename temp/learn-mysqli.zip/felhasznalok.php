<?php

require_once 'connect.php';

if (isset($_POST['submit'])) {
  if (
    isset($_POST['vezeteknev'], $_POST['keresztnev'], $_POST['adatok']) &&
    !empty($_POST['vezeteknev']) && !empty($_POST['keresztnev'])
  ) {
    
    $vezeteknev = htmlentities(htmlspecialchars($db->real_escape_string(trim($_POST['vezeteknev']))));
    $keresztnev = htmlentities(htmlspecialchars($db->real_escape_string(trim($_POST['keresztnev']))));
    $adatok = htmlentities(htmlspecialchars($db->real_escape_string(trim($_POST['adatok']))));
  
  $db->query(
    "
    INSERT INTO `emberek` (`id`, `vezeteknev`, `keresztnev`, `adatok`, `csatlakozas`)
    VALUES (NULL, '{$vezeteknev}','{$keresztnev}','{$adatok}', NOW() ) 
    "
  );

  echo '<pre>';
  print_r($db);
  
  }
} else {
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MySQLi</title>
</head>

<body>

  <?php
  if ($result = $db->query("SELECT * FROM `emberek`")) {
    if ($result->num_rows) {
      $table = $result->fetch_all(MYSQLI_NUM);
      echo '<table border="1">';
      echo '<thead>';
      echo '<tr>';
      echo '<th>ID</th>';
      echo '<th>Vezetéknév</th>';
      echo '<th>Keresztnév</th>';
      echo '<th>Adat</th>';
      echo '<th>Csatlakozás</th>';
      echo '</tr>';
      echo '</thead>';
      echo '<tbody>';
      foreach ($table as $row) {
        echo '<tr>';
        foreach ($row as $record) {
          echo '<td>' . $record . '</td>';
        }
        echo '</tr>';
      }
      echo '</tbody>';
      echo '</table>';
    } else {
      echo '<p>Nincs megjeleníthető adat. </p>';
    }
    $result->free();
  }

  ?>
  <hr />
  <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
    <div>
      <label for="vezeteknev">Vezetéknév</label><br />
      <input type="text" name="vezeteknev" />
    </div>
    <div>
      <label for="keresztnev">Keresztnév</label><br />
      <input type="text" name="keresztnev" />
    </div>
    <div>
      <label for="adatok">Magamról</label><br />
      <textarea name="adatok" id="" cols="30" rows="2"></textarea>
    </div>
    <div>
      <input type="submit" name="submit" value="Elküld" />
    </div>
  </form>

</body>

</html>

<?php 
 $db->close();
?>