<?php

require_once 'connect.php';

if (isset($_GET['keresztnev']) && !empty($_GET['keresztnev'])) {
  $keresztnev = trim($_GET['keresztnev']);
  $id = $_GET['id'];

  $myQuery = $db->prepare("SELECT `id`, `vezeteknev`, `keresztnev` FROM `emberek` WHERE `keresztnev`=? OR `id`=?");
  if ($myQuery == false) {
    echo '<pre>';
    print_r($db->error_list[0]['error']);
  }
  
  $myQuery->bind_param('si', $keresztnev, $id);
  $myQuery->execute();
  $myQuery->bind_result($id, $veznev, $kernev);

  while($myQuery->fetch()) {
    echo $id . ': ' . $veznev . ' ' . $kernev . '<br />';
  }
  
}


$db->close();